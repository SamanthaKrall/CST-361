/**
 * 
 */
/**
 * @author Samantha Krall
 *
 */
module FacadeDemo {
}