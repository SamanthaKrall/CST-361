package FacadeDemo;

public interface Shape {
	void draw();

}
