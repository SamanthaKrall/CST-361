/**
 * 
 */
/**
 * @author Samantha Krall
 *
 */
module ChainOfResponsibilityDemo {
}